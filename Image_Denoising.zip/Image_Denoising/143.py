import cv2
import numpy as np
import matplotlib.pyplot as plt
import os

# Function to calculate PSNR
def calculate_psnr(original, denoised):
    mse = np.mean((original - denoised) ** 2)
    if mse == 0:
        return 100  # Perfect match
    max_pixel = 255.0
    psnr = 20 * np.log10(max_pixel / np.sqrt(mse))
    return psnr

# Function to add salt-and-pepper noise
def add_salt_and_pepper_noise(image, salt_prob, pepper_prob):
    noisy_image = np.copy(image)
    total_pixels = image.size
    num_salt = np.ceil(salt_prob * total_pixels)
    coords = [np.random.randint(0, i - 1, int(num_salt)) for i in image.shape[:2]]
    noisy_image[coords[0], coords[1], :] = 255  # Salt noise

    num_pepper = np.ceil(pepper_prob * total_pixels)
    coords = [np.random.randint(0, i - 1, int(num_pepper)) for i in image.shape[:2]]
    noisy_image[coords[0], coords[1], :] = 0  # Pepper noise
    return noisy_image

# Dataset path (update this to your local path)
dataset_path = r"D:\testing images"  # Adjust this path
salt_prob = 0.02
pepper_prob = 0.02

# Iterate through images in the dataset
psnr_values = []

for filename in os.listdir(dataset_path):
    if filename.endswith(('.jpg', '.png', '.jpeg')):  # Add other formats if needed
        image_path = os.path.join(dataset_path, filename)
        image = cv2.imread(image_path, cv2.IMREAD_COLOR)

        if image is None:
            print(f"Image not found or unable to load: {filename}")
            continue

        # Add noise to the image
        noisy_image = add_salt_and_pepper_noise(image, salt_prob, pepper_prob)

        # Apply median filter to denoise the image
        denoised_image = cv2.medianBlur(noisy_image, 5)

        # Calculate PSNR
        psnr_value = calculate_psnr(image, denoised_image)
        psnr_values.append(psnr_value)

        # Display the results for each image (optional)
        plt.figure(figsize=(12, 6))
        plt.subplot(1, 3, 1)
        plt.title('Original Image')
        plt.imshow(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        plt.axis('off')

        plt.subplot(1, 3, 2)
        plt.title('Noisy Image')
        plt.imshow(cv2.cvtColor(noisy_image, cv2.COLOR_BGR2RGB))
        plt.axis('off')

        plt.subplot(1, 3, 3)
        plt.title('Denoised Image\nPSNR: {:.2f} dB'.format(psnr_value))
        plt.imshow(cv2.cvtColor(denoised_image, cv2.COLOR_BGR2RGB))
        plt.axis('off')

        plt.tight_layout()
        plt.show()

# Print overall accuracy rating
average_psnr = np.mean(psnr_values)
print(f"Average PSNR across all images: {average_psnr:.2f} dB") 